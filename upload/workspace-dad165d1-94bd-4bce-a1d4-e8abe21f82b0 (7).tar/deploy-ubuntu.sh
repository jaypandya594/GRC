#!/usr/bin/env bash
# =============================================================================
# iSecurify GRC Platform — Ubuntu 22.04 LTS Deployment Script
# =============================================================================
# This script performs a fresh production deployment of iSecurify on an Ubuntu
# server. It is idempotent — safe to re-run.
#
# Usage:
#   chmod +x deploy-ubuntu.sh
#   sudo ./deploy-ubuntu.sh
#
# Prerequisites:
#   - Ubuntu 22.04 LTS (or 20.04) with root/sudo access
#   - Outbound internet access for package downloads
#
# After deployment:
#   - App runs on http://YOUR_SERVER_IP:3000
#   - Managed by PM2 (auto-restarts, starts on boot)
#   - SQLite DB at /opt/isecurify/db/custom.db
#   - Logs: pm2 logs isecurify
# =============================================================================
set -euo pipefail

APP_DIR="/opt/isecurify"
APP_USER="isecurify"
DB_DIR="${APP_DIR}/db"
PORT="${PORT:-3000}"

echo "===================================================="
echo "  iSecurify GRC — Ubuntu Deployment"
echo "  App dir: ${APP_DIR}"
echo "  Port:    ${PORT}"
echo "===================================================="

# ----------------------------------------------------------------------------
# 0. Pre-flight checks
# ----------------------------------------------------------------------------
if [[ $EUID -ne 0 ]]; then
  echo "ERROR: This script must be run as root (use sudo)."
  exit 1
fi

# Resolve script location to find the project source
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Script located at: ${SCRIPT_DIR}"

# ----------------------------------------------------------------------------
# 1. System packages
# ----------------------------------------------------------------------------
echo ""
echo "[1/8] Installing system packages..."
apt-get update -y
apt-get install -y curl unzip git ca-certificates build-essential python3

# ----------------------------------------------------------------------------
# 2. Bun runtime
# ----------------------------------------------------------------------------
echo ""
echo "[2/8] Installing Bun..."
if ! command -v bun &>/dev/null; then
  curl -fsSL https://bun.sh/install | bash
  export BUN_INSTALL="$HOME/.bun"
  export PATH="$BUN_INSTALL/bin:$PATH"
else
  echo "  Bun already installed: $(bun --version)"
fi

# ----------------------------------------------------------------------------
# 3. Node.js (required by PM2 and Next.js standalone server)
# ----------------------------------------------------------------------------
echo ""
echo "[3/8] Installing Node.js LTS..."
if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
  apt-get install -y nodejs
else
  echo "  Node already installed: $(node --version)"
fi

# ----------------------------------------------------------------------------
# 4. PM2 process manager
# ----------------------------------------------------------------------------
echo ""
echo "[4/8] Installing PM2..."
if ! command -v pm2 &>/dev/null; then
  npm install -g pm2
else
  echo "  PM2 already installed: $(pm2 --version)"
fi

# ----------------------------------------------------------------------------
# 5. Create application user & directories
# ----------------------------------------------------------------------------
echo ""
echo "[5/8] Setting up application user and directories..."
if ! id -u "${APP_USER}" &>/dev/null; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "${APP_USER}"
  echo "  Created system user: ${APP_USER}"
fi
mkdir -p "${APP_DIR}" "${DB_DIR}"
mkdir -p "${APP_DIR}/public/uploads"

# ----------------------------------------------------------------------------
# 6. Copy project source (if running from the project repo)
# ----------------------------------------------------------------------------
echo ""
echo "[6/8] Copying project source to ${APP_DIR}..."
# Copy everything except node_modules, .next, .git, and the local dev db
if [[ -f "${SCRIPT_DIR}/package.json" ]]; then
  rsync -a --delete \
    --exclude='node_modules' \
    --exclude='.next' \
    --exclude='.git' \
    --exclude='db/*.db' \
    --exclude='dev.log' \
    --exclude='server.log' \
    "${SCRIPT_DIR}/" "${APP_DIR}/"
  echo "  Source copied."
else
  echo "  WARNING: No package.json found next to this script."
  echo "  Assuming the project source is already present in ${APP_DIR}."
fi

# ----------------------------------------------------------------------------
# 7. Configure .env
# ----------------------------------------------------------------------------
echo ""
echo "[7/8] Configuring .env..."
if [[ ! -f "${APP_DIR}/.env" ]]; then
  # Generate a random secret
  GENERATED_SECRET="$(openssl rand -base64 48 2>/dev/null || head -c 48 /dev/urandom | base64)"
  cat > "${APP_DIR}/.env" <<EOF
DATABASE_URL="file:${DB_DIR}/custom.db"
NODE_ENV="production"
NEXTAUTH_SECRET="${GENERATED_SECRET}"
PORT=${PORT}
EOF
  echo "  .env created with a generated NEXTAUTH_SECRET."
else
  echo "  .env already exists — leaving unchanged."
fi

# ----------------------------------------------------------------------------
# 8. Install dependencies, build, seed, and start
# ----------------------------------------------------------------------------
echo ""
echo "[8/8] Installing dependencies and building..."
cd "${APP_DIR}"
bun install

# Create the database and apply schema
echo "  Pushing Prisma schema to SQLite..."
bunx prisma db push --skip-generate
bunx prisma generate

# Seed (creates Super Admin + frameworks/controls)
if [[ -f "${APP_DIR}/prisma/seed.ts" ]]; then
  echo "  Running seed script..."
  bun run prisma/seed.ts || echo "  (seed may have already run — continuing)"
fi

# Build for production
echo "  Building Next.js production bundle..."
bun run build

# Fix ownership
chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"

# Start / restart with PM2
echo ""
echo "Starting with PM2..."
pm2 delete isecurify 2>/dev/null || true
pm2 start "bun .next/standalone/server.js" \
  --name isecurify \
  --cwd "${APP_DIR}" \
  --env production
pm2 save

# Configure PM2 to start on boot
pm2 startup systemd -u root --hp /root 2>/dev/null || true

# ----------------------------------------------------------------------------
# Done
# ----------------------------------------------------------------------------
echo ""
echo "===================================================="
echo "  ✓ Deployment complete!"
echo "===================================================="
echo ""
echo "  App:          http://$(hostname -I | awk '{print $1}'):${PORT}"
echo "  App dir:      ${APP_DIR}"
echo "  Database:     ${DB_DIR}/custom.db"
echo "  .env:         ${APP_DIR}/.env"
echo "  PM2 process:  isecurify"
echo ""
echo "  Super Admin login:"
echo "    Email:    superadmin@isecurify.com"
echo "    Password: Admin@123  (CHANGE THIS IMMEDIATELY after first login)"
echo ""
echo "  Useful commands:"
echo "    pm2 status              — view process status"
echo "    pm2 logs isecurify      — view live logs"
echo "    pm2 restart isecurify   — restart the app"
echo "    cd ${APP_DIR} && bunx prisma studio  — inspect the DB"
echo ""
echo "  Next steps:"
echo "    1. Set up Nginx as a reverse proxy (see docs)"
echo "    2. Configure SSL with Let's Encrypt (certbot)"
echo "    3. Configure the firewall: sudo ufw allow 80,443/tcp"
echo "===================================================="
