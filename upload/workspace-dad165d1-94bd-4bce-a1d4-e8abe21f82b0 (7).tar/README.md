# iSecurify GRC Platform

> Multi-tenant Governance, Risk & Compliance (GRC) SaaS platform for ISO 27001, SOC 2, GDPR, HIPAA, PCI DSS & NIST CSF.

---

## Executive Summary

**iSecurify** is a production-grade, multi-tenant Governance, Risk & Compliance platform built as a unified Next.js fullstack application. It enables Managed Service Providers (MSPs), consulting firms, and enterprise security teams to onboard multiple client organizations (tenants), assign role-based users to each tenant, and manage end-to-end compliance workflows against industry-standard frameworks.

The platform ships with **6 pre-loaded compliance frameworks** (ISO/IEC 27001:2022, SOC 2 Type II, GDPR, HIPAA, PCI DSS v4.0, NIST CSF) and **227 pre-mapped controls**. Key capabilities include:

- **Multi-tenant architecture** — each client company is isolated with its own users, evidence, risks, policies, and audits.
- **Role-Based Access Control (RBAC)** — 5 roles: Super Admin, Tenant Admin, Compliance Officer, Auditor, Employee.
- **Evidence Vault** — upload files (PDF, images, Office, CSV, ZIP up to 25 MB) and attach external links as compliance evidence, mapped to specific controls.
- **Control lifecycle management** — track implementation status (Not Started → In Progress → Implemented → Compliant) per tenant per control.
- **Bulk control import** — from Word (.docx), CSV, or JSON files with automatic header-column detection.
- **Risk register** with 5×5 inherent/residual heatmap, vulnerability tracker, policy management, audit scheduling with task tracking, and compliance checklists with inline answering.
- **Compliance dashboards** — radar charts, status pies, vulnerability bars, framework progress, and company-scoped reporting (CSV/HTML/JSON export).
- **Authentication** — custom session-based auth with scrypt password hashing, httpOnly cookies, self-service password change, admin password reset, and forgot-password (token-based) flows.

The application runs as a single Next.js process (frontend + API in one codebase) backed by a SQLite database via Prisma ORM, making it trivially deployable on a single Ubuntu server without external databases or containers.

---

## Technology Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| **Frontend Framework** | Next.js (App Router) | 16.1.1 |
| **UI Runtime** | React | 19 |
| **Language** | TypeScript | 5 |
| **Styling** | Tailwind CSS | 4 |
| **UI Component Library** | shadcn/ui (New York style) + Radix UI primitives | 48 components |
| **Icons** | lucide-react | 0.525 |
| **Charts** | Recharts | 2.15 |
| **State Management (client)** | Zustand | 5 |
| **State Management (server)** | TanStack Query | 5.82 |
| **Forms** | React Hook Form + Zod | 7.60 / 4.0 |
| **Toasts** | Sonner | 2.0 |
| **Animations** | Framer Motion | 12.23 |
| **Backend Framework** | Next.js API Routes (App Router, same process) | 16.1.1 |
| **Database** | SQLite | (via Prisma) |
| **ORM** | Prisma | 6.11 |
| **Authentication** | Custom session-based (scrypt hash, httpOnly cookie, `Session` + `PasswordReset` tables) | — |
| **File Parsing** | mammoth (.docx → HTML) | 1.12 |
| **Image Processing** | Sharp | 0.34 |
| **Runtime** | Bun | 1.x |
| **Process Manager** | PM2 | latest |
| **Reverse Proxy** | Nginx (recommended) or Apache2 | — |
| **Package Manager** | Bun (lockfile: `bun.lock`) | — |

---

## Complete Folder Structure

```
isecurify/
├── .env                          # Environment variables (DATABASE_URL, etc.)
├── package.json                  # Dependencies + scripts (dev, build, start, db:*)
├── bun.lock                      # Bun lockfile
├── next.config.ts                # Next.js config (output: "standalone")
├── tsconfig.json                 # TypeScript config (@/* → ./src/*)
├── tailwind.config.ts            # Tailwind theme config
├── postcss.config.mjs            # PostCSS (Tailwind plugin)
├── eslint.config.mjs             # ESLint config (Next.js + React rules)
├── Caddyfile                     # Caddy gateway (sandbox preview only)
├── deploy-ubuntu.sh              # Idempotent Ubuntu 22.04 deployment script
│
├── prisma/
│   ├── schema.prisma             # 19 Prisma models + relations
│   └── seed.ts                   # Seeds Super Admin + frameworks + controls
│
├── public/
│   ├── isecurify-icon.png        # Brand logo icon (favicon, sidebar)
│   ├── isecurify-logo.png        # Brand logo (horizontal, with text)
│   ├── logo.svg                  # Fallback logo
│   ├── robots.txt
│   └── uploads/                  # Evidence file uploads (created at runtime, per-tenant subdirs)
│
├── db/
│   └── custom.db                 # SQLite database file
│
└── src/
    ├── app/
    │   ├── layout.tsx            # Root layout (fonts, Toaster, Sonner, metadata)
    │   ├── page.tsx              # Single route — renders LoginPage or AppShell
    │   ├── globals.css           # iSecurify brand palette (OKLCH) + dark mode + scrollbar
    │   └── api/                  # 25 API route files (REST endpoints)
    │       ├── auth/             # login, logout, me, change-password, reset-password,
    │       │                     #   forgot-password, reset-password-confirm
    │       ├── dashboard/        # Aggregated stats + charts (supports ?tenantId= scoping)
    │       ├── tenants/          # CRUD for client companies (super_admin)
    │       ├── users/            # CRUD for users (admin-scoped)
    │       ├── frameworks/       # GET/POST/DELETE compliance frameworks
    │       ├── controls/         # GET/POST/DELETE controls + /import (bulk)
    │       ├── control-assignments/  # PATCH per-tenant control status
    │       ├── evidence/         # GET/POST/PATCH/DELETE + /upload (multipart)
    │       ├── checklists/       # GET + /[id] detail + /answer (upsert)
    │       ├── audits/           # GET/POST/PATCH/DELETE + /[id] + /[id]/tasks
    │       ├── vulnerabilities/  # CRUD
    │       ├── risks/            # CRUD
    │       ├── policies/         # CRUD
    │       ├── notifications/    # GET + PATCH (mark read)
    │       └── route.ts          # Health check root
    │
    ├── components/
    │   ├── app/
    │   │   ├── AppShell.tsx      # Sidebar + topbar + view router + sticky footer
    │   │   ├── LoginPage.tsx     # 3-mode auth (login / forgot / reset)
    │   │   ├── NotificationsMenu.tsx
    │   │   └── views/            # 13 feature views
    │   │       ├── DashboardView.tsx
    │   │       ├── FrameworksView.tsx
    │   │       ├── ControlsView.tsx
    │   │       ├── EvidenceView.tsx
    │   │       ├── ChecklistsView.tsx
    │   │       ├── AuditsView.tsx
    │   │       ├── VulnerabilitiesView.tsx
    │   │       ├── RisksView.tsx
    │   │       ├── PoliciesView.tsx
    │   │       ├── ReportsView.tsx
    │   │       ├── TenantsView.tsx
    │   │       ├── UsersView.tsx
    │   │       ├── SettingsView.tsx
    │   │       └── shared.tsx    # PageHeader, EmptyState, StatPill
    │   └── ui/                   # 48 shadcn/ui components (button, card, dialog, etc.)
    │
    ├── lib/
    │   ├── db.ts                 # Prisma client singleton
    │   ├── auth.ts               # hashPassword, verifyPassword, session, RBAC helpers
    │   ├── api.ts                # fetch wrapper with global 401 handling + date formatters
    │   ├── stores.ts             # Zustand stores (auth, UI)
    │   ├── types.ts              # SessionUser, ROLE_LABELS, STATUS_BADGE constants
    │   └── utils.ts              # cn() class merge helper
    │
    └── hooks/
        ├── use-mobile.ts
        └── use-toast.ts
```

---

## Environment Variables

### Backend / Application `.env`

| Variable | Description | Example | Required |
|----------|-------------|---------|----------|
| `DATABASE_URL` | Prisma datasource connection string. SQLite uses `file:` scheme. | `file:./db/custom.db` (dev) or `file:/opt/isecurify/db/custom.db` (prod) | **Yes** |
| `NODE_ENV` | Node environment. Set to `production` for deployments. | `production` | Recommended |
| `NEXTAUTH_SECRET` | Secret string (kept for compatibility; used as a general app secret). Generate with `openssl rand -base64 48`. | `a1B2c3...` | Recommended |
| `PORT` | Port the Next.js server listens on. | `3000` | No (default 3000) |

### `.env` (current — development)

```bash
DATABASE_URL="file:/home/z/my-project/db/custom.db"
```

### `.env.example` (production)

```bash
# Database — SQLite (absolute path recommended in production)
DATABASE_URL="file:/opt/isecurify/db/custom.db"

# Application
NODE_ENV="production"
PORT=3000

# Secret (generate with: openssl rand -base64 48)
NEXTAUTH_SECRET="REPLACE_WITH_RANDOM_64_CHAR_STRING"
```

### Frontend `.env`

This is a **unified fullstack app** — there is no separate frontend `.env`. The Next.js frontend and API share the same process and the same `.env` file. The frontend calls API routes via relative paths (`/api/...`), so no `API_URL` is needed.

> **Note:** If you later split the frontend and backend into separate services, you would add `NEXT_PUBLIC_API_URL=http://api.example.com` to the frontend `.env` and configure CORS on the backend.

---

## Database Setup

### Current Database Provider: SQLite

The application uses **SQLite** via Prisma, with the database file at `db/custom.db` (development) or `/opt/isecurify/db/custom.db` (production). SQLite is ideal for single-server deployments — no external database process is required.

### Prisma Models (19 tables)

| Model | Purpose | Key Relations |
|-------|---------|---------------|
| `Tenant` | Client company | has many Users, Evidence, Risks, Policies, Audits |
| `User` | Platform user | belongs to Tenant (optional for Super Admin) |
| `Session` | Auth session (httpOnly cookie token) | belongs to User |
| `PasswordReset` | Forgot-password tokens (1-hour expiry) | belongs to User |
| `Framework` | Compliance framework (ISO 27001, SOC 2, etc.) | has many Controls, Checklists, Audits |
| `Control` | Individual control within a framework | belongs to Framework; has many Assignments, Evidence |
| `ControlAssignment` | Per-tenant control implementation status | belongs to Tenant + Control |
| `Evidence` | Uploaded file or link evidence | belongs to Tenant, Control (optional), User |
| `Checklist` | Compliance questionnaire | belongs to Tenant, Framework (optional) |
| `ChecklistItem` | Question within a checklist | belongs to Checklist |
| `ChecklistAnswer` | Answer to a checklist item | belongs to ChecklistItem + User |
| `Vulnerability` | Security vulnerability | belongs to Tenant |
| `Risk` | Risk register entry | belongs to Tenant |
| `Policy` | Governance policy | belongs to Tenant |
| `PolicyApproval` | Policy approval record | belongs to Policy + User |
| `Audit` | Audit engagement | belongs to Tenant, Framework (optional) |
| `AuditTask` | Task within an audit | belongs to Audit, User (assignee) |
| `AuditLog` | Audit trail of all actions | belongs to User (optional), Tenant (optional) |
| `Notification` | In-app notification | belongs to User/Tenant |

### Migration Commands

```bash
# Apply schema to database (creates tables, no migration history)
bun run db:push

# Generate Prisma Client (TypeScript types)
bun run db:generate

# Create + apply a named migration (creates migration files in prisma/migrations/)
bun run db:migrate

# Reset database (DROPS all data — destructive!)
bun run db:reset
```

### How to Migrate from SQLite to MySQL

If you need MySQL for multi-server scalability or concurrency, follow these steps:

**1. Install MySQL server:**
```bash
sudo apt install -y mysql-server
sudo mysql_secure_installation
```

**2. Create database + user:**
```bash
sudo mysql -e "CREATE DATABASE isecurify CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
sudo mysql -e "CREATE USER 'isecurify'@'localhost' IDENTIFIED BY 'YOUR_STRONG_PASSWORD';"
sudo mysql -e "GRANT ALL PRIVILEGES ON isecurify.* TO 'isecurify'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"
```

**3. Update `prisma/schema.prisma` datasource:**
```prisma
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}
```

**4. Update `.env` connection string:**
```bash
DATABASE_URL="mysql://isecurify:YOUR_STRONG_PASSWORD@localhost:3306/isecurify"
```

**5. Recreate the schema on MySQL:**
```bash
# Remove the old SQLite DB reference, then:
bun run db:push    # creates all tables in MySQL
bun run db:generate
bun run prisma/seed.ts   # re-seed Super Admin + frameworks + controls
```

> **Note:** The Prisma schema uses `String @id @default(cuid())` and `DateTime` types that are compatible with both SQLite and MySQL. No schema field changes are required — only the `datasource` provider and `DATABASE_URL` change. SQLite-specific features (none used here) would need adjustment.

### MySQL Connection String Examples

```bash
# Local MySQL
DATABASE_URL="mysql://isecurify:password@localhost:3306/isecurify"

# Remote MySQL with SSL
DATABASE_URL="mysql://isecurify:password@db.example.com:3306/isecurify?sslaccept=verify-ca"

# PlanetScale (serverless MySQL)
DATABASE_URL="mysql://USER:PASSWORD@host.psdb.cloud/isecurify?sslaccept=strict"
```

---

## Local Development Setup

```bash
# 1. Clone the repository
git clone <your-repo-url> isecurify
cd isecurify

# 2. Install dependencies (Bun is the package manager)
bun install

# 3. Configure environment
cp .env.example .env   # then edit DATABASE_URL if needed
# (Development default: DATABASE_URL="file:./db/custom.db")

# 4. Create the database + apply schema
mkdir -p db
bun run db:push

# 5. Generate Prisma Client
bun run db:generate

# 6. Seed the database (creates Super Admin + 6 frameworks + 227 controls)
bun run prisma/seed.ts

# 7. Start the development server (http://localhost:3000)
bun run dev
```

**Default Super Admin credentials after seeding:**
```
Email:    superadmin@isecurify.com
Password: Admin@123   ← CHANGE THIS IMMEDIATELY after first login (Settings → Change Password)
```

**Other useful commands:**
```bash
bun run lint          # ESLint check
bun run build         # Production build (outputs .next/standalone/)
bun run start         # Start production server (requires build first)
```

---

## Production Deployment on Ubuntu 22.04

### Server Preparation

```bash
# Update the system
sudo apt update && sudo apt upgrade -y

# Install essential build tools + utilities
sudo apt install -y git curl unzip build-essential python3 ca-certificates rsync ufw fail2ban
```

### Runtime Installation

The project uses **Bun** (runtime + package manager) and **Node.js** (required by PM2 and the Next.js standalone server).

```bash
# Install Bun
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc

# Install Node.js 20 LTS (required by PM2)
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo bash -
sudo apt install -y nodejs

# Install PM2 globally
sudo npm install -g pm2
```

**Required versions:**
- Bun ≥ 1.0
- Node.js ≥ 20 LTS
- PM2 ≥ 5

### Database Deployment

#### Option A: SQLite (default — single server)

```bash
# Create the database directory
sudo mkdir -p /opt/isecurify/db
sudo chown -R www-data:www-data /opt/isecurify/db

# The database file is created automatically on first `prisma db push`
```

SQLite is production-ready for single-server deployments handling up to ~thousands of concurrent users. Enable WAL mode for better concurrency by adding to your Prisma schema or running:
```sql
PRAGMA journal_mode=WAL;
```

#### Option B: MySQL (multi-server / high-concurrency)

```bash
# Install MySQL 8
sudo apt install -y mysql-server
sudo mysql_secure_installation

# Create database + user
sudo mysql <<EOF
CREATE DATABASE isecurify CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'isecurify'@'localhost' IDENTIFIED BY 'CHANGE_THIS_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON isecurify.* TO 'isecurify'@'localhost';
FLUSH PRIVILEGES;
EOF

# Update .env: DATABASE_URL="mysql://isecurify:CHANGE_THIS_STRONG_PASSWORD@localhost:3306/isecurify"
# Update prisma/schema.prisma: provider = "mysql"
# Then: bun run db:push && bun run db:generate && bun run prisma/seed.ts
```

### Deploy the Application

```bash
# Create application directory + system user
sudo useradd --system --no-create-home --shell /usr/sbin/nologin isecurify
sudo mkdir -p /opt/isecurify

# Copy project source (from your local machine or CI)
sudo rsync -a --exclude='node_modules' --exclude='.next' --exclude='.git' \
  ./ /opt/isecurify/

# OR use the included deployment script (does all of the below automatically):
sudo chmod +x deploy-ubuntu.sh
sudo ./deploy-ubuntu.sh
```

**Manual steps (if not using the script):**

```bash
cd /opt/isecurify

# Configure .env
sudo tee /opt/isecurify/.env > /dev/null <<EOF
DATABASE_URL="file:/opt/isecurify/db/custom.db"
NODE_ENV="production"
PORT=3000
NEXTAUTH_SECRET="$(openssl rand -base64 48)"
EOF

# Install dependencies
sudo bun install

# Apply schema + generate client + seed
sudo bunx prisma db push --skip-generate
sudo bunx prisma generate
sudo bun run prisma/seed.ts

# Build for production (creates .next/standalone/)
sudo bun run build

# Create upload directory
sudo mkdir -p /opt/isecurify/public/uploads
sudo chown -R isecurify:isecurify /opt/isecurify
```

---

## Build Process

The `package.json` defines these scripts:

| Command | What it does |
|---------|-------------|
| `bun run dev` | Starts Next.js dev server on port 3000 with hot reload. Pipes output to `dev.log`. |
| `bun run build` | Runs `next build` (creates `.next/standalone/` self-contained server) then copies `.next/static` and `public/` into the standalone dir. |
| `bun run start` | Runs `bun .next/standalone/server.js` in production mode. Requires a prior `build`. Pipes output to `server.log`. |
| `bun run lint` | Runs ESLint (`eslint .`) to check code quality. |
| `bun run db:push` | Runs `prisma db push` — applies schema to DB without creating migration files. |
| `bun run db:generate` | Runs `prisma generate` — regenerates the Prisma Client TypeScript types. |
| `bun run db:migrate` | Runs `prisma migrate dev` — creates + applies a named migration. |
| `bun run db:reset` | Runs `prisma migrate reset` — **destructive**: drops all data and re-applies migrations. |

### Build Output

The `next.config.ts` sets `output: "standalone"`, which produces a self-contained server bundle in `.next/standalone/` that includes only the necessary `node_modules`. This is what PM2 runs in production.

---

## PM2 Deployment

### ecosystem.config.js

Create this file in `/opt/isecurify/`:

```javascript
module.exports = {
  apps: [{
    name: 'isecurify',
    script: '.next/standalone/server.js',
    cwd: '/opt/isecurify',
    instances: 1,                    // Single instance (SQLite is single-writer)
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
    },
    max_memory_restart: '1G',
    error_file: '/var/log/isecurify/error.log',
    out_file: '/var/log/isecurify/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    autorestart: true,
    max_restarts: 10,
    restart_delay: 3000,
  }],
}
```

### PM2 Commands

```bash
# Start the application
cd /opt/isecurify
pm2 start ecosystem.config.js

# Save the process list (so it survives reboots)
pm2 save

# Configure PM2 to start on boot
pm2 startup systemd -u root --hp /root
# (Run the command PM2 outputs)

# Monitoring
pm2 status                    # Process list
pm2 logs isecurify            # Live logs (Ctrl+C to exit)
pm2 logs isecurify --lines 100  # Last 100 lines
pm2 monit                     # Real-time CPU/memory monitor
pm2 restart isecurify         # Restart the app
pm2 reload isecurify          # Zero-downtime reload
pm2 stop isecurify            # Stop
pm2 delete isecurify          # Remove from PM2
```

---

## NGINX Deployment (Recommended Reverse Proxy)

### Production NGINX Configuration

Create `/etc/nginx/sites-available/isecurify.conf`:

```nginx
# Redirect HTTP → HTTPS
server {
    listen 80;
    server_name isecurify.example.com www.isecurify.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name isecurify.example.com www.isecurify.example.com;

    # SSL certificates (Let's Encrypt — see SSL Setup section)
    ssl_certificate     /etc/letsencrypt/live/isecurify.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/isecurify.example.com/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;
    ssl_prefer_server_ciphers on;
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;

    # Upload size limit (must match app's 25MB evidence limit + headroom)
    client_max_body_size 30M;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/x-javascript
        application/json
        application/xml
        application/xml+rss
        font/woff
        font/woff2
        image/svg+xml;

    # Reverse proxy to Next.js (PM2-managed on port 3000)
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_buffering off;
    }

    # Serve static uploads directly (faster than going through Node)
    location /uploads/ {
        alias /opt/isecurify/public/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        add_header X-Content-Type-Options "nosniff" always;
    }

    # Cache Next.js static assets aggressively
    location /_next/static/ {
        proxy_pass http://127.0.0.1:3000;
        expires 365d;
        add_header Cache-Control "public, immutable";
    }

    # Let's Encrypt challenge
    location ^~ /.well-known/acme-challenge/ {
        root /var/www/html;
        default_type "text/plain";
    }
}
```

### Enable the site

```bash
sudo ln -s /etc/nginx/sites-available/isecurify.conf /etc/nginx/sites-enabled/
sudo nginx -t                    # Test configuration
sudo systemctl reload nginx
```

---

## Apache2 Deployment

### Apache VirtualHost Configuration

Create `/etc/apache2/sites-available/isecurify.conf`:

```apache
<VirtualHost *:80>
    ServerName isecurify.example.com
    Redirect permanent / https://isecurify.example.com/
</VirtualHost>

<VirtualHost *:443>
    ServerName isecurify.example.com
    DocumentRoot /opt/isecurify/public

    # SSL
    SSLEngine on
    SSLCertificateFile      /etc/letsencrypt/live/isecurify.example.com/fullchain.pem
    SSLCertificateKeyFile   /etc/letsencrypt/live/isecurify.example.com/privkey.pem
    SSLProtocol             all -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite          ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256

    # Security headers
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"

    # Upload limit
    LimitRequestBody 31457280

    # Reverse proxy to Next.js
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/

    # WebSocket support
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule ^/?(.*) "ws://127.0.0.1:3000/$1" [P,L]

    # Serve uploads directly
    Alias /uploads /opt/isecurify/public/uploads
    <Directory /opt/isecurify/public/uploads>
        Require all granted
        Options -Indexes
    </Directory>

    ErrorLog  ${APACHE_LOG_DIR}/isecurify_error.log
    CustomLog ${APACHE_LOG_DIR}/isecurify_access.log combined
</VirtualHost>
```

### Enable Apache modules + site

```bash
sudo a2enmod ssl proxy proxy_http proxy_wstunnel rewrite headers
sudo a2ensite isecurify
sudo a2dissite 000-default
sudo apache2ctl configtest
sudo systemctl reload apache2
```

### Architecture Comparison

| Architecture | When to use | Notes |
|-------------|-------------|-------|
| **Nginx only** | Recommended for this project | Best performance, simpler config, excellent for static + reverse proxy. Use this unless you have a specific reason for Apache. |
| **Apache only** | Existing Apache infrastructure | Works fine with `mod_proxy`. Slightly higher memory overhead than Nginx. |
| **Nginx + Apache** | Complex stacks (e.g., Apache serving PHP apps alongside Next.js) | Nginx as front proxy → Apache on another port → Next.js. Overkill for this single-app deployment. |

---

## SSL Setup (Let's Encrypt)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx   # for Nginx
# OR
sudo apt install -y certbot python3-certbot-apache  # for Apache

# Obtain + install SSL certificate (interactive)
sudo certbot --nginx -d isecurify.example.com -d www.isecurify.example.com
# OR for Apache:
sudo certbot --apache -d isecurify.example.com -d www.isecurify.example.com

# Test automatic renewal
sudo certbot renew --dry-run
```

Certbot installs a systemd timer that auto-renews certificates 30 days before expiry. Renewals are automatic — no further action needed.

---

## File Upload Directories

Evidence files are uploaded to `public/uploads/{tenantId}/` and served via the `/uploads/` path. The directory is created automatically per-tenant on first upload, but for production you should pre-create it with correct permissions:

```bash
# Create the upload root
sudo mkdir -p /opt/isecurify/public/uploads

# Set ownership to the user running the Next.js process (isecurify or www-data)
sudo chown -R isecurify:isecurify /opt/isecurify/public/uploads

# Permissions: directory 755, files 644
sudo find /opt/isecurify/public/uploads -type d -exec chmod 755 {} \;
sudo find /opt/isecurify/public/uploads -type f -exec chmod 644 {} \;
```

**Allowed file types** (enforced in `/api/evidence/upload`): PDF, PNG, JPEG, GIF, WebP, SVG, XLSX, DOCX, XLS, DOC, CSV, TXT, ZIP, JSON, XML. **Max size:** 25 MB.

---

## Backup Strategy

### Database Backup (SQLite)

```bash
#!/bin/bash
# /opt/isecurify/backup-db.sh
BACKUP_DIR="/var/backups/isecurify"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p "$BACKUP_DIR"

# SQLite backup (uses .backup command for consistent copy while running)
sqlite3 /opt/isecurify/db/custom.db ".backup '$BACKUP_DIR/db_$DATE.sqlite'"

# Compress
gzip "$BACKUP_DIR/db_$DATE.sqlite"

# Retain last 30 days
find "$BACKUP_DIR" -name "db_*.sqlite.gz" -mtime +30 -delete

echo "Backup complete: $BACKUP_DIR/db_$DATE.sqlite.gz"
```

**Cron schedule** (daily at 2 AM):
```bash
sudo crontab -e
# Add:
0 2 * * * /opt/isecurify/backup-db.sh >> /var/log/isecurify-backup.log 2>&1
```

### Database Backup (MySQL)

```bash
mysqldump --single-transaction --routines --triggers \
  -u isecurify -p'PASSWORD' isecurify | gzip > /var/backups/isecurify/db_$(date +%Y%m%d).sql.gz
```

### Upload Backup

```bash
# Backup evidence files
rsync -a /opt/isecurify/public/uploads/ /var/backups/isecurify/uploads/

# Or tar + compress
tar -czf /var/backups/isecurify/uploads_$(date +%Y%m%d).tar.gz -C /opt/isecurify/public uploads/
```

### Application Backup

```bash
# Full application backup (excluding node_modules + .next)
tar --exclude='node_modules' --exclude='.next' --exclude='dev.log' \
    -czf /var/backups/isecurify/app_$(date +%Y%m%d).tar.gz /opt/isecurify/
```

### Restore

```bash
# SQLite restore
bun run db:reset   # CAUTION: drops current data
sqlite3 /opt/isecurify/db/custom.db < /var/backups/isecurify/db_YYYYMMDD.sql

# Uploads restore
tar -xzf /var/backups/isecurify/uploads_YYYYMMDD.tar.gz -C /opt/isecurify/public/
sudo chown -R isecurify:isecurify /opt/isecurify/public/uploads
```

---

## Monitoring

### PM2 Logs

```bash
pm2 logs isecurify                  # Live stdout + stderr
pm2 logs isecurify --err            # Errors only
pm2 logs isecurify --lines 500      # Last 500 lines
pm2 logs isecurify --json           # JSON format (for log aggregators)
```

Log files: `/var/log/isecurify/out.log` and `/var/log/isecurify/error.log`

### Application Logs

The app writes to `dev.log` (development) or `server.log` (production start script). Prisma query logs go to stdout.

```bash
tail -f /opt/isecurify/server.log
```

### Nginx Logs

```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Apache Logs

```bash
tail -f /var/log/apache2/isecurify_access.log
tail -f /var/log/apache2/isecurify_error.log
```

### Log Rotation

```bash
sudo tee /etc/logrotate.d/isecurify > /dev/null <<EOF
/var/log/isecurify/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0644 isecurify isecurify
    sharedscripts
    postrotate
        pm2 reload isecurify >/dev/null 2>&1 || true
    endscript
}
EOF
```

---

## Security Hardening

### UFW Firewall

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp           # SSH (consider rate-limiting)
sudo ufw allow 80/tcp           # HTTP
sudo ufw allow 443/tcp          # HTTPS
sudo ufw enable
sudo ufw status verbose
```

### Fail2Ban (SSH brute-force protection)

```bash
sudo apt install -y fail2ban
sudo tee /etc/fail2ban/jail.local > /dev/null <<EOF
[sshd]
enabled = true
port = 22
maxretry = 3
bantime = 3600
findtime = 600
EOF
sudo systemctl enable fail2ban
sudo systemctl restart fail2ban
```

### SSH Hardening

Edit `/etc/ssh/sshd_config`:
```sshd_config
PermitRootLogin no
PasswordAuthentication yes   # Set to "no" after setting up SSH keys
PubkeyAuthentication yes
Port 22                      # Or change to a non-standard port
MaxAuthTries 3
AllowUsers yourusername      # Restrict to specific users
```

```bash
sudo systemctl restart sshd
```

### File Permissions

```bash
# Application code: read-only for the app user
sudo chown -R root:root /opt/isecurify
sudo chown -R isecurify:isecurify /opt/isecurify/db /opt/isecurify/public/uploads /opt/isecurify/.env
sudo chmod 600 /opt/isecurify/.env                    # Env file: owner read/write only
sudo chmod 640 /opt/isecurify/db/custom.db            # Database: owner+group read
sudo chmod -R 755 /opt/isecurify/public               # Public assets: readable
sudo find /opt/isecurify/src -type f -exec chmod 644 {} \;  # Source: readable
```

### Additional Recommendations

- **Change the Super Admin password** immediately after deployment (Settings → Change Password).
- **Enable HTTPS only** — the session cookie is set with `secure: false` for sandbox compatibility; change to `secure: true` in `src/lib/auth.ts` for production behind HTTPS.
- **Set `httpOnly: true`** (already set) and `sameSite: 'strict'` (currently `'lax'`) for tighter CSRF protection.
- **Regularly update dependencies**: `bun update && bun audit`.
- **Database backups**: automated daily (see Backup Strategy).

---

## Troubleshooting Guide

| Issue | Cause | Solution |
|-------|-------|----------|
| **`prisma:query` errors: Unknown field** | Running dev server has a stale Prisma Client after schema changes. | Restart the dev server: `pkill -f "next dev" && bun run dev` |
| **500 on `/api/checklists` or `/api/audits`** | Missing Prisma relation (e.g., `framework` not declared on `Checklist` model). | Ensure the schema has the `framework Framework? @relation(...)` field, then `bun run db:push` + restart server. |
| **Login fails with "Tenant account is suspended"** | The `tenant.status` field wasn't included in the login query. | Fixed in current code; verify `/api/auth/login` includes `status: true` in the tenant select. |
| **"Unauthorized" runtime error (401 crashes view)** | An API call returned 401 and the view didn't handle it. | Fixed — `src/lib/api.ts` now catches 401 globally and resets auth state. |
| **Evidence upload returns 413** | File exceeds 25 MB limit. | Reduce file size, or increase `client_max_body_size` in Nginx and the check in `/api/evidence/upload`. |
| **Evidence upload returns 400 "File type not allowed"** | MIME type not in the allowed list. | Add the MIME type to the `allowedTypes` array in `src/app/api/evidence/upload/route.ts`. |
| **`.docx` import shows "No tables found"** | The Word document doesn't contain a table, or the table has no header row. | Ensure the .docx has a table with column headers (Control ID, Control Name, etc.) in the first row. |
| **PM2 process exits immediately** | Missing `.env` file or build output. | Ensure `bun run build` completed and `.env` exists with `DATABASE_URL`. Check `pm2 logs isecurify`. |
| **Nginx 502 Bad Gateway** | Next.js not running or wrong port. | Check `pm2 status` — process should be `online`. Verify `PORT=3000` in `.env` and Nginx proxies to `127.0.0.1:3000`. |
| **Charts not rendering** | Recharts needs a defined height container. | Ensure the `ResponsiveContainer` has a parent with explicit height. |
| **Sidebar not visible on mobile** | Sheet component requires the mobile menu trigger. | Click the hamburger menu (☰) in the topbar on screens < 1024px. |
| **Database locked (SQLite)** | Another process holds a write lock. | Ensure only one PM2 instance runs. For high concurrency, migrate to MySQL. |

---

## Production Go-Live Checklist

### Pre-Deployment
- [ ] Change Super Admin password from default (`Admin@123`)
- [ ] Generate a strong `NEXTAUTH_SECRET` (`openssl rand -base64 48`)
- [ ] Set `NODE_ENV=production` in `.env`
- [ ] Set `secure: true` for the session cookie in `src/lib/auth.ts` (behind HTTPS)
- [ ] Set `sameSite: 'strict'` for the session cookie (tighter CSRF protection)
- [ ] Configure `DATABASE_URL` with an absolute path (SQLite) or MySQL connection
- [ ] Run `bun run lint` — no errors
- [ ] Run `bun run build` — completes successfully

### Server Setup
- [ ] Ubuntu 22.04 LTS updated (`apt update && apt upgrade`)
- [ ] Bun, Node.js 20 LTS, PM2 installed
- [ ] UFW firewall enabled (allow 22, 80, 443 only)
- [ ] Fail2Ban configured for SSH
- [ ] SSH hardened (key auth, no root login)
- [ ] System user `isecurify` created

### Application
- [ ] Code deployed to `/opt/isecurify/`
- [ ] `.env` configured with production values
- [ ] `bun install` completed
- [ ] `bun run db:push` + `bun run db:generate` completed
- [ ] `bun run prisma/seed.ts` run (Super Admin + frameworks created)
- [ ] `bun run build` completed (`.next/standalone/` exists)
- [ ] `public/uploads/` directory created with correct ownership
- [ ] PM2 process started: `pm2 start ecosystem.config.js`
- [ ] `pm2 save` + `pm2 startup` configured (auto-restart on reboot)

### Reverse Proxy + SSL
- [ ] Nginx (or Apache) configured as reverse proxy to `127.0.0.1:3000`
- [ ] `client_max_body_size 30M` set (for evidence uploads)
- [ ] Gzip compression enabled
- [ ] Security headers configured (HSTS, X-Frame-Options, etc.)
- [ ] Let's Encrypt SSL certificate installed
- [ ] HTTPS redirect (80 → 443) working
- [ ] Auto-renewal tested (`certbot renew --dry-run`)

### Backup & Monitoring
- [ ] Database backup script configured (daily cron)
- [ ] Upload backup configured
- [ ] Log rotation configured (`/etc/logrotate.d/isecurify`)
- [ ] PM2 monitoring accessible (`pm2 monit`)

### Smoke Tests
- [ ] Visit `https://your-domain.com` — login page loads
- [ ] Login as Super Admin — dashboard renders with charts
- [ ] Create a test tenant + user — appears in lists
- [ ] Upload a test evidence file — downloads correctly
- [ ] Import controls via .docx — controls appear in catalog
- [ ] Test forgot-password flow — token generated, password reset works
- [ ] Test admin password reset — user can login with new password
- [ ] Check `pm2 logs isecurify` — no errors
- [ ] Check Nginx logs — no 502/504 errors

### Post Go-Live
- [ ] Remove the test tenant + user created during smoke tests
- [ ] Document the production Super Admin credentials in a password manager
- [ ] Schedule weekly dependency audits (`bun audit`)
- [ ] Set up monitoring alerts (PM2, disk space, backup success)
- [ ] Create real tenants and onboard real users

---

## License

Proprietary — © 2024 iSecurify. All rights reserved.

---

**Built with:** Next.js 16 · React 19 · TypeScript 5 · Tailwind CSS 4 · shadcn/ui · Prisma 6 · SQLite · Bun · PM2 · Nginx
