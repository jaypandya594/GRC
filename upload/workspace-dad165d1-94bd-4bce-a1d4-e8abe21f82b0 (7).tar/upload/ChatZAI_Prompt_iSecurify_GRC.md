# Chat Z AI Prompt — iSecurify GRC Platform: Complete Build

---

## CONTEXT — WHAT ALREADY EXISTS

You are continuing development of **iSecurify GRC** — a multi-tenant Governance, Risk & Compliance (GRC) SaaS platform. The existing codebase is a **Next.js 16 (App Router) + TypeScript + Prisma + SQLite + shadcn/ui + Tailwind CSS v4** fullstack app. The runtime is **Bun**.

**Tech Stack (do not change):**
- **Frontend:** Next.js 16, React 19, TypeScript, Tailwind CSS v4, shadcn/ui, Zustand, Sonner (toasts)
- **Backend:** Next.js API Routes (same repo), Prisma ORM, SQLite
- **Auth:** Custom session-based auth (no NextAuth), tokens stored in `Session` table
- **DB:** SQLite at `file:./db/custom.db`

**Existing .env:**
```
DATABASE_URL=file:./db/custom.db
NEXTAUTH_SECRET=your-secret-here
```

---

## WHAT IS MISSING — FIX ALL 6 ITEMS BELOW

---

### MISSING ITEM 1: Add & Delete Compliance Frameworks

**Problem:** `FrameworksView.tsx` only displays frameworks in read-only card grid. There is NO ability to add a new framework or delete an existing one. The `GET /api/frameworks` route exists but there is no `POST` or `DELETE` handler.

**Fix Required:**

**A) Update `/src/app/api/frameworks/route.ts` — add POST and DELETE:**

```typescript
// POST /api/frameworks — create a new framework (super_admin only)
export async function POST(req: NextRequest) {
  const user = await getSessionUser()
  if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { code, name, description, category, version, icon } = body
  if (!code || !name) return NextResponse.json({ error: 'code and name required' }, { status: 400 })
  const existing = await db.framework.findUnique({ where: { code } })
  if (existing) return NextResponse.json({ error: 'Framework code already exists' }, { status: 409 })
  const fw = await db.framework.create({ data: { code, name, description, category, version, icon } })
  return NextResponse.json({ framework: fw }, { status: 201 })
}

// DELETE /api/frameworks?id=xxx — delete framework + all its controls (super_admin only)
export async function DELETE(req: NextRequest) {
  const user = await getSessionUser()
  if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const id = new URL(req.url).searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  await db.framework.delete({ where: { id } }) // cascades to controls via schema
  return NextResponse.json({ ok: true })
}
```

**B) Update `FrameworksView.tsx` — add "Add Framework" button and delete icon on each card:**

- Show "Add Framework" button in PageHeader `actions` prop — visible only to `super_admin`
- Clicking opens a Dialog with fields: Code (e.g. ISO27001), Name, Description, Category (dropdown: security/privacy/financial/healthcare), Version, Icon (dropdown from FRAMEWORK_ICONS keys)
- Each framework card gets a trash icon (top-right) visible only to `super_admin`; clicking prompts `confirm()` then calls DELETE
- After add/delete, refresh the frameworks list

---

### MISSING ITEM 2: View Controls in Detail + Add/Import Controls per Framework

**Problem:** `ControlsView.tsx` shows controls in an accordion but:
1. No way to add individual controls to a framework
2. No way to import a bulk list of controls (CSV or JSON)
3. The detail expanded view is minimal — no full modal with all fields

**Fix Required:**

**A) Update `/src/app/api/controls/route.ts` — add POST handler:**

```typescript
// POST /api/controls — create a new control (super_admin only)
export async function POST(req: NextRequest) {
  const user = await getSessionUser()
  if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { frameworkId, ref, title, description, category, guidance, order } = await req.json()
  if (!frameworkId || !ref || !title) return NextResponse.json({ error: 'frameworkId, ref and title required' }, { status: 400 })
  const control = await db.control.create({ data: { frameworkId, ref, title, description, category, guidance, order: order || 0 } })
  return NextResponse.json({ control }, { status: 201 })
}
```

**B) Add `/src/app/api/controls/import/route.ts` — bulk import:**

```typescript
// POST /api/controls/import — accepts array of controls for a frameworkId
export async function POST(req: NextRequest) {
  const user = await getSessionUser()
  if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { frameworkId, controls } = await req.json()
  // controls = [{ ref, title, description?, category?, guidance?, order? }]
  if (!frameworkId || !Array.isArray(controls)) return NextResponse.json({ error: 'Invalid payload' }, { status: 400 })
  const created = await db.control.createMany({
    data: controls.map((c: any, i: number) => ({ frameworkId, ref: c.ref, title: c.title, description: c.description || null, category: c.category || null, guidance: c.guidance || null, order: c.order ?? i })),
    skipDuplicates: true,
  })
  return NextResponse.json({ created: created.count })
}
```

**C) Update `ControlsView.tsx`:**

- Add two buttons in PageHeader `actions` (visible to `super_admin` only):
  1. **"Add Control"** — opens Dialog with fields: Ref, Title, Description, Category, Guidance, Order. Pre-selects current framework.
  2. **"Import Controls"** — opens a Dialog with:
     - A `<textarea>` for pasting JSON array: `[{"ref":"A.5.1","title":"...","description":"...","category":"...","guidance":"..."}]`
     - A file upload `<input type="file" accept=".json,.csv">` that reads the file and populates the textarea
     - CSV format hint: `ref,title,description,category,guidance` (first row = header)
     - Parse CSV client-side into JSON before posting
     - "Import N Controls" submit button
- When a control card is expanded, add a **"View Full Details"** button that opens a full-screen Dialog/Sheet showing ALL fields: ref, title, description, category, guidance, implementation notes, owner, status, evidence count, with the "Update Status" form embedded inside.

---

### MISSING ITEM 3: Checklist — Properly Visible with Full Details per Company

**Problem:** `ChecklistsView.tsx` shows checklist cards but:
1. Clicking a card does nothing — no drill-down
2. The checklist items/questions are never shown
3. There is no company (tenant) selector to view one company's checklists separately
4. No "View Checklist Detail" button

**Fix Required:**

**A) Update `/src/app/api/checklists/route.ts` — ensure it returns items and answers:**

Add a `GET /api/checklists/[id]` route at `/src/app/api/checklists/[id]/route.ts`:

```typescript
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const checklist = await db.checklist.findUnique({
    where: { id: params.id },
    include: {
      framework: true,
      items: { orderBy: { order: 'asc' } },
      answers: { include: { user: { select: { name: true, email: true } } } },
    },
  })
  if (!checklist) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  // tenant guard
  if (user.role !== 'super_admin' && checklist.tenantId !== user.tenantId)
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  return NextResponse.json({ checklist })
}
```

**B) Update `ChecklistsView.tsx`:**

- Add a **company (tenant) selector dropdown** at the top (visible to `super_admin` — already partially done but make it prominent with a label "Filter by Company:")
- Each checklist card must have a **"View Details →"** button
- Clicking "View Details" opens a full-width **Sheet** (side panel) or navigates to a detail view showing:
  - Checklist title, description, framework badge, status, due date
  - **All checklist items** rendered as a proper checklist:
    - Each item shows: question text, hint (if any), type badge (yes/no, text, rating)
    - If answered: show the answer value + who answered + timestamp
    - If not answered: show greyed out "Not answered yet"
  - Progress bar at the top (X of Y answered)
  - An **"Answer"** button on each unanswered item (for compliance officers) that opens an inline form

---

### MISSING ITEM 4: Audits — Properly Visible with Full Details per Company

**Problem:** `AuditsView.tsx` shows audit cards but:
1. No drill-down to see full audit details and tasks
2. Tasks are shown as just a progress bar — not the actual task list
3. No company-wise filter that clearly shows "this audit belongs to Company X"
4. No "View Audit" button

**Fix Required:**

**A) Add `/src/app/api/audits/[id]/route.ts`:**

```typescript
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const audit = await db.audit.findUnique({
    where: { id: params.id },
    include: {
      framework: true,
      tenant: { select: { id: true, name: true } },
      tasks: {
        orderBy: [{ order: 'asc' }, { createdAt: 'asc' }],
        include: { assignee: { select: { id: true, name: true, email: true } } },
      },
    },
  })
  if (!audit) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (user.role !== 'super_admin' && audit.tenantId !== user.tenantId)
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  return NextResponse.json({ audit })
}
```

**B) Update `AuditsView.tsx`:**

- Add a **"Filter by Company"** select dropdown (for `super_admin`) — label it clearly as "Company:" not just a dropdown
- Each audit card must show the **company name** as a badge when viewed by super_admin (fetch tenant name)
- Add a **"View Details →"** button on each audit card
- Clicking "View Details" opens a **Sheet** (full side panel) showing:
  - Audit header: title, type badge, status badge, framework badge
  - Company: tenant name (for super_admin)
  - Lead auditor, scope, date range
  - **Full task list** as a proper kanban-style or table showing:
    - Task title, description, assignee name, status badge, due date
    - Each task has a status dropdown to update inline
  - Progress summary (done/total)
  - "Add Task" button inside the detail panel

**C) Add task status update endpoint `/src/app/api/audits/[id]/tasks/route.ts`:**
```typescript
// POST = create task, PATCH = update task status
// PATCH body: { taskId, status }
// POST body: { title, description, assigneeId, dueDate }
```

---

### MISSING ITEM 5: Company-wise Selection for Reports

**Problem:** `ReportsView.tsx` shows ALL data merged together. There is no way to generate a report for a single company. Reports export covers the entire platform, not per-company.

**Fix Required:**

**A) Update `ReportsView.tsx`:**

- Add a **"Select Company"** dropdown at the very top (for `super_admin`):
  - Options: "All Companies (Platform-wide)" + each tenant
  - Default: "All Companies"
- When a specific company is selected:
  - All stats cards update to show that company's data only
  - Framework compliance chart shows only that company's controls
  - Export buttons (CSV, HTML, JSON) generate a report scoped to that company only
  - Show a banner: "Showing report for: **[Company Name]**"
- The `exportHTML()`, `exportCSV()`, `exportJSON()` functions must include `tenantId` filter in the title and data

**B) Update `/src/app/api/dashboard/route.ts` to accept `?tenantId=xxx`:**

```typescript
// In GET handler, check searchParams for tenantId
const tenantId = searchParams.get('tenantId')
// If provided and user is super_admin, scope all queries to that tenantId
// Return tenantName in the response for the banner
```

---

### MISSING ITEM 6: Fix .env and Deployment for Ubuntu Server

**The correct `.env` file for Ubuntu deployment:**

```bash
# .env (production — copy to project root)
DATABASE_URL="file:/opt/isecurify/db/custom.db"
NEXTAUTH_SECRET="generate-a-random-64-char-string-here"
NODE_ENV="production"
```

**Generate NEXTAUTH_SECRET on Ubuntu:**
```bash
openssl rand -base64 48
```

**Deployment steps for Ubuntu (no Docker, no external DB):**
```bash
# 1. Install Bun
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc

# 2. Clone/upload your project to /opt/isecurify
mkdir -p /opt/isecurify
cd /opt/isecurify

# 3. Install dependencies
bun install

# 4. Set up .env
echo 'DATABASE_URL="file:/opt/isecurify/db/custom.db"' > .env
echo 'NEXTAUTH_SECRET="YOUR_GENERATED_SECRET"' >> .env
echo 'NODE_ENV="production"' >> .env

# 5. Create DB directory and run migrations
mkdir -p /opt/isecurify/db
bunx prisma db push
bunx prisma db seed  # if seed.ts exists

# 6. Build
bun run build

# 7. Start (use PM2 for production)
npm install -g pm2
pm2 start "bun .next/standalone/server.js" --name isecurify
pm2 save
pm2 startup
```

---

## COMPLETE FILE CHANGE SUMMARY

Apply ALL of the following changes to produce the final working app:

### New/Modified API Routes:
| File | Change |
|---|---|
| `src/app/api/frameworks/route.ts` | Add `POST` and `DELETE` handlers |
| `src/app/api/controls/route.ts` | Add `POST` handler |
| `src/app/api/controls/import/route.ts` | **NEW FILE** — bulk import |
| `src/app/api/checklists/[id]/route.ts` | **NEW FILE** — single checklist detail |
| `src/app/api/audits/[id]/route.ts` | **NEW FILE** — single audit detail |
| `src/app/api/audits/[id]/tasks/route.ts` | **NEW FILE** — create/update tasks |
| `src/app/api/dashboard/route.ts` | Add `tenantId` query filter support |

### Modified Frontend Views:
| File | Change |
|---|---|
| `src/components/app/views/FrameworksView.tsx` | Add/Delete framework dialogs |
| `src/components/app/views/ControlsView.tsx` | Add control dialog, Import dialog, Full detail Sheet |
| `src/components/app/views/ChecklistsView.tsx` | Company filter, detail Sheet with all items & answers |
| `src/components/app/views/AuditsView.tsx` | Company filter with tenant name, detail Sheet with full task list |
| `src/components/app/views/ReportsView.tsx` | Company selector, scoped exports |

---

## CODE QUALITY REQUIREMENTS

1. **TypeScript** — all new code must be fully typed, no `any` unless unavoidable
2. **Auth guards** — every API route must call `getSessionUser()` and check role where needed
3. **Super admin gates** — Add/Delete framework and Add/Import controls are `super_admin` only. Regular tenant users can only view/update their own data.
4. **Toast feedback** — all actions must use `toast.success()` / `toast.error()` via sonner
5. **Loading states** — all async operations must show a loading spinner or skeleton
6. **Empty states** — use existing `<EmptyState>` component when lists are empty
7. **Responsive** — all new Dialogs/Sheets must be mobile-friendly (use `max-w-lg` for dialogs, full-width Sheet for detail panels)
8. **Consistent styling** — follow the existing pattern: `Badge`, `Card`, `CardContent`, `Button`, `Dialog`, `Sheet` from shadcn/ui
9. **No breaking changes** — all existing features (dashboard, risks, vulnerabilities, policies, evidence, users, tenants) must continue working

---

## DATABASE SCHEMA — REFERENCE ONLY (DO NOT CHANGE)

The Prisma schema already has all needed models. Key relationships:
- `Framework` → has many `Control` (cascade delete)
- `Control` → has many `ControlAssignment` (per tenant)
- `Checklist` → has many `ChecklistItem` → has many `ChecklistAnswer`
- `Audit` → has many `AuditTask`
- `Tenant` → owns checklists, audits, risks, policies, etc.

---

## DELIVERABLE

Produce the complete updated source code for all 12 files listed in the "COMPLETE FILE CHANGE SUMMARY" table above. Each file should be the full file content (not a diff). Output them one by one in order. After all files, provide the complete `.env` template and the Ubuntu deployment script as a bash file.
